package com.cpsc476;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Arrays;
import java.util.Base64;
//import java.util.HashMap;
import java.util.Map;
 
@WebServlet("/private")
public class PrivateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static int click_counter = 0;
	protected static pojo[] pj=new pojo[100];	//array of user objects
	public int numusers=0;		
	//number of users
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   
	
	   if(request.getSession().getAttribute("username") == null)
       {
           response.sendRedirect("login");
           return;
       }
	   
	   //redirect to long url when you click on short url link
	   String action= (String) request.getParameter("action");
	   if (action.equals("redirect")){
	     String url=(String) request.getParameter("url");
	     String longUrl="";
	    // int clicks = 
	     
	     for(String item: PublicServlet.database.keySet()){
		    Url shortUrl = (Url) PublicServlet.database.get(item);
		    if (shortUrl.getUrl().equals(url)){  
			    longUrl=item;
			    shortUrl.Click();	
			    System.out.println(longUrl);//increment clicks
			    System.out.println("my urls"+ shortUrl.getClicks());
			   response.sendRedirect("http://"+ longUrl);
			  
		    }
		    request.setAttribute("count", shortUrl.getClicks());
		    request.getRequestDispatcher("/WEB-INF/jsp/view/private.jsp")
	           .forward(request, response);
	     }
	 
	   }if(action.equals("view"))
	   {
	   String uname=(String)request.getSession().getAttribute("username");
	   request.setAttribute("username", uname);
	//   System.out.println("getusername"+uname);
 //  	System.out.println("pj in GET /private before showListURL is " + Arrays.deepToString(PrivateServlet.pj));
	   String x[][]= showListURL(request, response);//shows list of urls shortened
   //	System.out.println("pj in GET /private after showListURL is" + Arrays.deepToString(PrivateServlet.pj));
	   System.out.println("click_counter"+x+click_counter);
	   request.setAttribute("clicks", click_counter);
	   request.setAttribute("url", x);
	   request.getRequestDispatcher("/WEB-INF/jsp/view/private.jsp")
           .forward(request, response);
	   
	  }
}


protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   
   String uname=(String)request.getSession().getAttribute("username");
	if(uname == null)
  {
      response.sendRedirect("login");
      return;
  }
  request.setAttribute("username", uname);
  String lurl=request.getParameter("longurl"); 
  String surl=this.createURL(request, response);		//shortens url
  String x[][]=this.showListURL(request, response);
   
   request.setAttribute("url", x);
   request.setAttribute("shorturl", surl);
   request.setAttribute("longurl", lurl);
   request.getRequestDispatcher("/WEB-INF/jsp/view/private.jsp").forward(request, response);
}

//performs Base64 encoding 
private String createURL(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{
    String longurl1=request.getParameter("longurl");

    String shorturlstr = Base64.getUrlEncoder().encodeToString(longurl1.getBytes("utf-8")).substring(1,7);

    String shorturl="http://localhost:8080/short/"+shorturlstr;
    Url u=new Url(shorturl);
    String uname=(String)request.getSession().getAttribute("username");
     
    PublicServlet.database.put(longurl1, u);	//insert into Database for public page
    
    //insert into database for user's private object
    Boolean b=false;	//user not present
    int m=0;
    
    //checks if current user is already present in array of user objects
    for(int i=0;i<numusers;i++){
    	if(pj[i].username==uname){
    		b=true;
    		m=i;
    		break;
    	}
    }
    
    //if user is not present create new user object and insert url in the object
    if(b!=true){
    	pj[numusers]=new pojo(uname);
    	pj[numusers].insertUrl(longurl1, u);
    	pj[numusers].showpojo();
    	numusers++;
    }     //if user is present just insert url in the object
    else{
    	pj[m].insertUrl(longurl1, u);
    	pj[m].showpojo();
    	
    	
    }
     
     
     return shorturl;

}

//display user's personal shortened url list
private String[][] showListURL(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{
	
    String uname=(String)request.getSession().getAttribute("username");
	int m=-1; 							//assuming user not present
	
    //checks if current user is already present in array of user objects
   	for(int i=0;i<numusers;i++){
		System.out.println("Comparing " + pj[i].username + " to " + uname);
		if(pj[i].username.equals(uname)){
			m=i;
			
			break;
		}
	}
    
    
	String[][] myStringArray = new String [100][100];		//stores the list of urls and clicks which will be displayed on jsp page
    
	int i=0;
    if(m!=-1){
    	int n=pj[m].database.size();
    	Url values[]=new Url[n];
    	
    	//stores short url and clicks for all urls user has shortened inside myStringArray
    	for (Map.Entry<String,Object> entry : pj[m].database.entrySet()) {
    		String key = entry.getKey();
    		values[i] = (Url)entry.getValue();
    		myStringArray[i][0]=values[i].getUrl();
    		myStringArray[i][1]=new Integer(values[i].getClicks()).toString();
    		i++;
    	}
    	//System.out.println(myStringArray);
    	//System.out.println(Arrays.deepToString(myStringArray));
	
    }
	
	
    return myStringArray;
}
}