package com.cpsc476;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cpsc476.Url;


public class PublicServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Map<String, Object> database= new HashMap<>();   
    
    
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	if (request.getSession().getAttribute("username")==null){
    	request.getRequestDispatcher("/WEB-INF/jsp/view/guest.jsp").forward(request,response);
    	}
	}
	
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		switch(action){
		case "guest":
		default:
			guest(request,response);
		}
    	
	}

    private void guest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	String shortUrl= request.getParameter("shortUrl");
	    Url urlObj = (Url) database.get(shortUrl);
       
	    if (database.size()== 0){
	    	request.setAttribute("emptyDB", true);
		    request.setAttribute("itemnotfound", false);
	    }
	    else if (urlObj != null){
	    String originalUrl= urlObj.getUrl();	    
	    request.setAttribute("url", originalUrl);
	    request.setAttribute("emptyDB", false);
	    request.setAttribute("itemnotfound", false);
	    }
	    else if(urlObj ==null){
		    request.setAttribute("itemnotfound", true);
		    request.setAttribute("emptyDB", false);
	    }
	
	    request.getRequestDispatcher("WEB-INF/jsp/view/public.jsp").forward(request, response);
    }
    
	

}
