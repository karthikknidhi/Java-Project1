package com.cpsc476;

import java.util.HashMap;
import java.util.Map;

//user object template
public class pojo {

	String username;
	protected Map<String, Object> database= new HashMap<>(); 
	public pojo(String username){
		this.username = username;
	}
	public void insertUrl( String l, Url u){
		database.put(l, u);

	}
	public Map<String, Map<String, Object>> showpojo(){
		System.out.println("user: "+this.username+" Map:"+this.database);
		Map<String,Map<String, Object>> result = new HashMap<>();
		result.put(this.username, this.database);
		return result;
	}
}
